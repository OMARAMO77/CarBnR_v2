-- MySQL dump 10.13  Distrib 8.0.28, for Linux (x86_64)
--
-- Host: localhost    Database: carbnr_dev_db
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `id` varchar(60) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `car_id` varchar(60) NOT NULL,
  `user_id` varchar(60) NOT NULL,
  `location_id` varchar(60) NOT NULL,
  `price_by_day` int NOT NULL,
  `pickup_date` datetime DEFAULT NULL,
  `return_date` datetime DEFAULT NULL,
  `total_cost` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `car_id` (`car_id`),
  KEY `user_id` (`user_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`),
  CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `bookings_ibfk_3` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES ('004202a5-f0fd-4192-928c-398fac8a4296','2024-02-14 17:18:47','2024-02-14 17:18:47','1200569c-3994-4706-bfaf-4a57cba0c0db','3b12889b-9931-4e4e-9f1a-5642a3dc6c8b','9631d214-dfe6-41fd-9580-319254951bfa',80,'2024-02-14 17:18:47','2024-03-14 17:18:47',870);
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cars` (
  `id` varchar(60) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `location_id` varchar(60) NOT NULL,
  `brand` varchar(128) NOT NULL,
  `model` varchar(128) NOT NULL,
  `year` varchar(128) NOT NULL,
  `price_by_day` int NOT NULL,
  `registration_number` varchar(128) NOT NULL,
  `available` tinyint(1) NOT NULL,
  `image_url` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `cars_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES ('1200569c-3994-4706-bfaf-4a57cba0c0db','2024-02-13 22:21:05','2024-02-13 22:21:05','9631d214-dfe6-41fd-9580-319254951bfa','Tesla','Model 3','2022',80,'YZA890',1,'https://media.ed.edmunds-media.com/tesla/model-3/2022/oem/2022 tesla model-3 sedan performance fq oem 1 815.jpg'),('37bf24c1-88d1-40e3-a85b-d57839658d52','2024-02-13 22:20:42','2024-02-13 22:20:42','f35534f2-580a-44dc-a6ab-4a14d2eb98c8','Ford','Escape','2021',55,'DEF789',1,'https://www.motortrend.com/uploads/sites/10/2015/11/2012-ford-escape-xlt-4wd-suv-angular-front.png?fit=around%7C875:492'),('4836d289-2702-4314-9843-e90562504295','2024-02-14 18:36:03','2024-02-14 18:36:03','c4cdc053-ef2f-46f9-a4e9-138e157d2c36','Mazda','Mazda3','2022',60,'STU234',1,'https://www.kbb.com/wp-content/uploads/2022/05/2022-Mazda3-2.5-Turbo-Premium-Plus-front-3qtr.jpg?w=918'),('488cb0a9-7d52-4931-bc27-f09a1831ea37','2024-02-13 22:20:48','2024-02-13 22:20:48','f35534f2-580a-44dc-a6ab-4a14d2eb98c8','Nissan','Altima','2020',48,'JKL345',1,'https://hips.hearstapps.com/hmg-prod/images/2019-nissan-altima-102-1538074559.jpg?crop=1.00xw:0.923xh;0,0&resize=1200:*'),('66efa9c1-3c7d-44b3-bf02-bf1a6af2743b','2024-02-13 22:21:08','2024-02-13 22:21:08','9631d214-dfe6-41fd-9580-319254951bfa','Audi','A4','2021',75,'BCD123',1,'https://hips.hearstapps.com/hmg-prod/images/2021-audi-a4-45-tfsi-quattro-106-1607927016.jpg?crop=0.678xw:0.572xh;0.138xw,0.334xh&resize=1200:*'),('677be2da-0db2-4caa-9dca-36a0955201c9','2024-02-13 22:20:35','2024-02-13 22:20:35','f35534f2-580a-44dc-a6ab-4a14d2eb98c8','Toyota','Camry','2022',50,'ABC123',1,'https://imgd.aeplcdn.com/664x374/n/cw/ec/110233/camry-exterior-right-front-three-quarter-3.jpeg?isig=0&q=80'),('8ddfafcc-b020-4e43-a8a4-31d46eb8d46d','2024-02-14 18:35:59','2024-02-14 18:35:59','c4cdc053-ef2f-46f9-a4e9-138e157d2c36','Kia','Optima','2019',42,'PQR901',1,'https://www.motortrend.com/uploads/sites/10/2018/12/2019-kia-optima-lx-sedan-angular-front.png?fit=around%7C875:492'),('a6ca4e9f-fd56-447b-8119-cda0e86ae433','2024-02-13 22:21:01','2024-02-13 22:21:01','9631d214-dfe6-41fd-9580-319254951bfa','Subaru','Impreza','2020',55,'VWX567',1,'https://hips.hearstapps.com/hmg-prod/images/2020-subaru-impreza-mmp-1-1570122739.jpg?crop=0.612xw:0.462xh;0.308xw,0.388xh&resize=1200:*'),('a86f8edf-297e-4d60-856b-1536724d55d5','2024-02-13 22:20:38','2024-02-13 22:20:38','f35534f2-580a-44dc-a6ab-4a14d2eb98c8','Honda','Civic','2020',45,'XYZ456',1,'https://imgd-ct.aeplcdn.com/664x415/n/cw/ec/27074/civic-exterior-left-front-three-quarter.jpeg?q=80'),('b1986181-200b-4cab-805c-0dabad1a20c2','2024-02-13 22:20:45','2024-02-13 22:20:45','f35534f2-580a-44dc-a6ab-4a14d2eb98c8','Chevrolet','Malibu','2019',40,'GHI012',1,'https://www.motortrend.com/uploads/sites/10/2018/11/2019-chevrolet-malibu-lt-sedan-angular-front.png?fit=around%7C875:492'),('c189325e-180f-4cbe-b301-838b046cd0b0','2024-02-14 18:35:55','2024-02-14 18:35:55','c4cdc053-ef2f-46f9-a4e9-138e157d2c36','Hyundai','Sonata','2021',52,'MNO678',1,'https://hips.hearstapps.com/hmg-prod/images/2021-hyundai-sonata-n-line-108-1606156377.jpg?crop=1.00xw:0.847xh;0,0.108xh&resize=1200:*');
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cities` (
  `id` varchar(60) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `state_id` varchar(60) NOT NULL,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `state_id` (`state_id`),
  CONSTRAINT `cities_ibfk_1` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES ('126a8d38-be70-4339-9468-5e5a631c63de','2024-02-13 22:12:09','2024-02-13 22:12:09','ebcf5e41-9036-4469-bdee-49dc03cd96ca','San Jose'),('412e239a-ad60-417f-a3ac-1e98b8536c9f','2024-02-13 22:12:12','2024-02-13 22:12:12','ebcf5e41-9036-4469-bdee-49dc03cd96ca','Oakland'),('62e19fa4-645a-4f0b-b80b-80fd3f657a42','2024-02-13 22:12:06','2024-02-13 22:12:06','ebcf5e41-9036-4469-bdee-49dc03cd96ca','Sacramento'),('6fa8fcf8-4bf2-4fa4-93a3-c281b5365441','2024-02-13 22:12:18','2024-02-13 22:12:18','ebcf5e41-9036-4469-bdee-49dc03cd96ca','Long Beach'),('746340db-198d-4259-b243-25e93d4bb3ba','2024-02-13 22:11:53','2024-02-13 22:11:53','ebcf5e41-9036-4469-bdee-49dc03cd96ca','Anaheim'),('7d4bf7a9-8b97-4808-80e0-9032ca4856f7','2024-02-13 22:11:50','2024-02-13 22:11:50','ebcf5e41-9036-4469-bdee-49dc03cd96ca','San Francisco'),('996e7248-30f4-4a6b-aa74-4b62b9b92551','2024-02-13 22:12:15','2024-02-13 22:12:15','ebcf5e41-9036-4469-bdee-49dc03cd96ca','Fresno'),('ac45bb98-1aad-4bbf-acbc-a9e0b86a1b01','2024-02-13 22:11:57','2024-02-13 22:11:57','ebcf5e41-9036-4469-bdee-49dc03cd96ca','Santa Monica'),('d5e5b5c4-ae7b-433a-9248-2a3c3f53b4fa','2024-02-13 22:11:59','2024-02-13 22:11:59','ebcf5e41-9036-4469-bdee-49dc03cd96ca','Los Angeles'),('fe8a854b-16ab-4e79-9e42-37e50b416ee9','2024-02-13 22:12:03','2024-02-13 22:12:03','ebcf5e41-9036-4469-bdee-49dc03cd96ca','San Diego');
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` varchar(60) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `city_id` varchar(60) NOT NULL,
  `name` varchar(128) NOT NULL,
  `address` varchar(128) NOT NULL,
  `phone_number` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `city_id` (`city_id`),
  CONSTRAINT `locations_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES ('1563978c-dae2-4a4b-b0ae-6ccb99d6670d','2024-02-13 22:15:01','2024-02-13 22:15:01','7d4bf7a9-8b97-4808-80e0-9032ca4856f7','SF Express Rentals','789 Olive Way','+4321098765'),('9631d214-dfe6-41fd-9580-319254951bfa','2024-02-13 22:15:14','2024-02-13 22:15:14','7d4bf7a9-8b97-4808-80e0-9032ca4856f7','Car Rental Center','456 Oak St','+9876543210'),('b2d0ea29-1102-4fce-bb94-43b6413e58aa','2024-02-13 22:15:08','2024-02-13 22:15:08','7d4bf7a9-8b97-4808-80e0-9032ca4856f7','Grove Car Hire','876 Juniper St','+6789012345'),('c4cdc053-ef2f-46f9-a4e9-138e157d2c36','2024-02-14 18:33:59','2024-02-14 18:33:59','7d4bf7a9-8b97-4808-80e0-9032ca4856f7','Pacific Car Rentals','456 Redwood Blvd','+2109876543'),('e463c16f-f0c4-4bbe-82ea-8a40548b12ed','2024-02-13 22:14:58','2024-02-13 22:14:58','7d4bf7a9-8b97-4808-80e0-9032ca4856f7','City Drive Auto','654 Cedar Ct','+3456789012'),('e5da20fe-777c-4598-ad31-e87a8f9d062d','2024-02-13 22:14:41','2024-02-13 22:14:41','7d4bf7a9-8b97-4808-80e0-9032ca4856f7','Fast Wheels Rentals','789 Maple Ave','+1234567890'),('edb1bb4b-ab0f-4980-beac-2c726c846ce1','2024-02-13 22:14:45','2024-02-13 22:14:45','7d4bf7a9-8b97-4808-80e0-9032ca4856f7','Bay Area Car Hire','321 Pine Dr','+8765432109'),('f015b3c8-f61e-485d-a417-f3fd9a1b1d0a','2024-02-13 22:14:49','2024-02-13 22:14:49','7d4bf7a9-8b97-4808-80e0-9032ca4856f7','Golden Gate Rent A Car','555 Cypress Ln','+2345678901'),('f35534f2-580a-44dc-a6ab-4a14d2eb98c8','2024-02-13 22:15:05','2024-02-13 22:15:05','7d4bf7a9-8b97-4808-80e0-9032ca4856f7','Bay City Car Rentals','234 Birch Ave','+5678901234'),('f3db5d9d-1c5d-4ef3-b937-15e1b09b61b1','2024-02-13 22:14:52','2024-02-13 22:14:52','7d4bf7a9-8b97-4808-80e0-9032ca4856f7','SF Auto Rentals','987 Elm Rd','+1098765432'),('f7284a65-4af5-4d84-87d6-0ff48ca4f92a','2024-02-13 22:15:11','2024-02-13 22:15:11','7d4bf7a9-8b97-4808-80e0-9032ca4856f7','SF Speedy Rentals','321 Magnolia Pl','+7890123456');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` varchar(60) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `car_id` varchar(60) NOT NULL,
  `user_id` varchar(60) NOT NULL,
  `location_id` varchar(60) DEFAULT NULL,
  `text` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `car_id` (`car_id`),
  KEY `user_id` (`user_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`),
  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `reviews_ibfk_3` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` VALUES ('218dfa41-434c-4817-8642-61cda5573eaa','2024-02-13 22:39:39','2024-02-13 22:39:39','1200569c-3994-4706-bfaf-4a57cba0c0db','3b12889b-9931-4e4e-9f1a-5642a3dc6c8b',NULL,'Impressive performance and sleek design.'),('514d84f3-a50b-43f4-8ccf-339445fdc430','2024-02-13 22:39:57','2024-02-13 22:39:57','488cb0a9-7d52-4931-bc27-f09a1831ea37','7b69d4c2-a19e-4e17-9490-4e2a5d660033',NULL,'Excellent service, highly recommend!'),('70e91a90-f5dc-4904-86dd-bead2a00382b','2024-02-13 22:40:00','2024-02-13 22:40:00','66efa9c1-3c7d-44b3-bf02-bf1a6af2743b','9d6e0f3a-8a61-4d2d-8e30-37043b37291c',NULL,'Spacious interior and fuel efficient.'),('9ab92265-ad07-4eff-bde3-85715df7540b','2024-02-13 22:40:10','2024-02-13 22:40:10','a86f8edf-297e-4d60-856b-1536724d55d5','e4037258-4082-4be8-bc32-e1a693022bba',NULL,'Reliable car with great gas mileage.'),('a8bb4aef-b5fc-4975-82dd-a6b28436376f','2024-02-13 22:40:07','2024-02-13 22:40:07','a6ca4e9f-fd56-447b-8119-cda0e86ae433','c45a1e8d-4602-45cc-b7f1-2487a91b38bb',NULL,'Smooth drive and modern features.'),('b44303ff-7f70-4815-9260-6d93fad841ea','2024-02-13 22:40:04','2024-02-13 22:40:04','677be2da-0db2-4caa-9dca-36a0955201c9','ab8d03ff-4c81-476a-b9b1-7bf1de939591',NULL,'Superb handling and comfortable seating.'),('b6c4c84d-44ef-4b25-a464-b668826b3b17','2024-02-13 22:39:50','2024-02-13 22:39:50','37bf24c1-88d1-40e3-a85b-d57839658d52','5b462786-3309-4269-9d0a-e0738e64cd6b',NULL,'Comfortable drive with advanced safety features.'),('cd884288-e428-4d96-91a1-d7fdf10179d0','2024-02-13 22:40:13','2024-02-13 22:40:13','b1986181-200b-4cab-805c-0dabad1a20c2','f8144007-a4c3-480e-87f6-3c0b5bdf33fb',NULL,'Awesome experience, will rent again!');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `states` (
  `id` varchar(60) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES ('ebcf5e41-9036-4469-bdee-49dc03cd96ca','2024-02-13 22:07:39','2024-02-13 22:07:39','California');
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(60) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `first_name` varchar(128) DEFAULT NULL,
  `last_name` varchar(128) DEFAULT NULL,
  `address` varchar(128) DEFAULT NULL,
  `phone_number` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('3b12889b-9931-4e4e-9f1a-5642a3dc6c8b','2024-02-13 22:24:02','2024-02-13 22:24:02','emma.davis@example.com','07916623cf5bab937b7dbada93ab3102','Emma','Davis','789 Olive Ave','+4321098765'),('43d611ce-3ffe-467d-97f4-c868d9ebeefd','2024-02-13 22:23:45','2024-02-13 22:23:45','bob.johnson@example.com','83a9f222cd358fcd1242874956e4c584','Bob','Johnson','789 Maple Dr','+8765432109'),('4813cc6e-5f6f-48bd-8722-884bc9c333b1','2024-02-13 22:24:11','2024-02-13 22:24:11','liam.turner@example.com','13eed07d404b6a6369f0d87db38d9b7e','Liam','Turner','321 Magnolia Rd','+7890123456'),('5b462786-3309-4269-9d0a-e0738e64cd6b','2024-02-13 22:23:55','2024-02-13 22:23:55','sophia.clark@example.com','45e5788231194a73cf0b3439fb273861','Sophia','Clark','987 Elm Ln','+2109876543'),('6db0fdf7-c05a-401d-975e-5e3b83110c51','2024-02-13 22:23:39','2024-02-13 22:23:39','john.doe@example.com','482c811da5d5b4bc6d497ffa98491e38','John','Doe','123 Main St','+1234567890'),('7b69d4c2-a19e-4e17-9490-4e2a5d660033','2024-02-13 22:24:08','2024-02-13 22:24:08','olivia.miller@example.com','7f1f18c51d99e661c6f0243ead4540a2','Olivia','Miller','876 Juniper Dr','+6789012345'),('9d6e0f3a-8a61-4d2d-8e30-37043b37291c','2024-02-13 22:24:05','2024-02-13 22:24:05','henry.moore@example.com','9f876785ec5425a0511339bed7230c2a','Henry','Moore','234 Birch Pl','+5678901234'),('ab8d03ff-4c81-476a-b9b1-7bf1de939591','2024-02-13 22:23:59','2024-02-13 22:23:59','charlie.baker@example.com','1ddbe83d4e2088939c8649dbf5f8ddfb','Charlie','Baker','654 Cedar St','+3456789012'),('c45a1e8d-4602-45cc-b7f1-2487a91b38bb','2024-02-13 22:23:42','2024-02-13 22:23:42','alice.smith@example.com','b4af804009cb036a4ccdc33431ef9ac9','Alice','Smith','456 Oak Ave','+9876543210'),('e4037258-4082-4be8-bc32-e1a693022bba','2024-02-13 22:23:49','2024-02-13 22:23:49','eva.jones@example.com','c073a3f30ec87a6e47380873a68fd9f3','Eva','Jones','321 Pine Ct','+2345678901'),('f8144007-a4c3-480e-87f6-3c0b5bdf33fb','2024-02-13 22:23:52','2024-02-13 22:23:52','michael.williams@example.com','4c3e1ec04215f69d6a8e9c023c9e4572','Michael','Williams','555 Cypress Rd','+1098765432');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-14 12:19:41
